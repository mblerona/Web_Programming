package mk.finki.ukim.mk.lab1_a.model.exceptions;

public class InvalidArgumentException extends RuntimeException{
public InvalidArgumentException(){
    super("Invalid Argument");
}
}
