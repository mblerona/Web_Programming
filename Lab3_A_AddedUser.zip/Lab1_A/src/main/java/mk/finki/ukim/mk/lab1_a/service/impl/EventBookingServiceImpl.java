package mk.finki.ukim.mk.lab1_a.service.impl;

import mk.finki.ukim.mk.lab1_a.model.Event;
import mk.finki.ukim.mk.lab1_a.model.EventBooking;
import mk.finki.ukim.mk.lab1_a.model.User;
import mk.finki.ukim.mk.lab1_a.repository.jpa.BookingRepository;
import mk.finki.ukim.mk.lab1_a.service.EventBookingService;
import mk.finki.ukim.mk.lab1_a.service.EventService;
import org.springframework.stereotype.Service;

@Service
public class EventBookingServiceImpl implements EventBookingService {

    private final BookingRepository bookingRepository;
    private final EventService eventService;

    public EventBookingServiceImpl(BookingRepository bookingRepository, EventService eventService) {
        this.bookingRepository = bookingRepository;
        this.eventService = eventService;
    }



    @Override
//    public EventBooking placeBooking(String eventName, int numTickets, User user) {
//        Event event = eventService.findByName(eventName)
//                .orElseThrow(() -> new IllegalArgumentException("Event not found"));
//        if (event.getNrTicketsPerEvent() < numTickets) {
//            throw new IllegalArgumentException("Not enough tickets available.");
//        }
//        event.setNrTicketsPerEvent(event.getNrTicketsPerEvent() - numTickets);
//
//        EventBooking booking = new EventBooking();
//        booking.setEventName(event.getName());
//        booking.setNumberOfTickets((long)numTickets);
//        booking.setUser(user);
//        bookingRepository.save(booking);
//        return booking;
//    }

    public EventBooking placeBooking(String eventName, int numTickets, User user) {
        Event event = eventService.findByName(eventName)
                .orElseThrow(() -> new IllegalArgumentException("Event not found"));

        if (event.getNrTicketsPerEvent() < numTickets) {
            throw new IllegalArgumentException("Not enough tickets available.");
        }

        // Update ticket count
        event.setNrTicketsPerEvent(event.getNrTicketsPerEvent() - numTickets);

        // Create a booking
        EventBooking booking = new EventBooking();
        booking.setEventName(event.getName());
        booking.setNumberOfTickets((long)numTickets);
        booking.setUser(user);
        booking.setAttendeeName(user.getName()); // Set the attendeeName explicitly

        bookingRepository.save(booking);

        return booking;
    }
}
