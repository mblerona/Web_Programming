package mk.finki.ukim.mk.lab1_a.web.controller;

import jakarta.servlet.http.HttpServletRequest;

import jakarta.servlet.http.HttpSession;
import mk.finki.ukim.mk.lab1_a.model.User;
import mk.finki.ukim.mk.lab1_a.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/login")
//controller - from requests, modifies model and returns a view
//restController - used to create restful aPI that wont return a view to user but data instead


public class LoginController {
    private final UserService userService;

    public LoginController(UserService userService) {
        this.userService = userService;
    }

    //@RequestMapping(method = RequestMethod.GET, value = "/login")
    @GetMapping
    public String getLoginPage() {
        // Return the name of the Thymeleaf template that will be used to render the login page
        return "login";
    }

//    @PostMapping
//    public String login(HttpServletRequest request, Model model) {
//        User user = null;
//
//        String username = request.getParameter("username");
//        String password = request.getParameter("password");
//
//        try {
//            user = userService.login(username, password);
//            request.getSession().setAttribute("user", user);
//            // Redirect to the home page
//            return "redirect:/listEvents";
//        } catch (RuntimeException ex) {
//            model.addAttribute("hasError", true);
//            model.addAttribute("error", ex.getMessage());
//            return "login";
//        }
//    }

    @PostMapping
    public String login(@RequestParam String username,
                        @RequestParam String password,
                        HttpSession session) {
        User user = userService.login(username, password);
        if (user != null) {
            // Store the username in the session
            session.setAttribute("loggedUser", username);
            return "redirect:/events";
        } else {
            return "redirect:/login?error=Invalid credentials";
        }
    }
}
