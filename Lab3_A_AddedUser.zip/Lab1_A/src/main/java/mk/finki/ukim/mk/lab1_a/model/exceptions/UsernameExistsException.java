package mk.finki.ukim.mk.lab1_a.model.exceptions;

public class UsernameExistsException extends RuntimeException{

    public UsernameExistsException(String username) {
        super(String.format("User with username already exists"));
    }
}
