//package mk.finki.ukim.mk.lab1_a.config;
//
//
//import org.springframework.context.annotation.Configuration;
//import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
//import org.springframework.security.config.annotation.web.configuration.WebSecurityConfiguration;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.security.web.SecurityFilterChain;
//
//@Configuration
//@EnableWebSecurity
//@EnableMethodSecurity
//public class WebSecurityConfig extends WebSecurityConfiguration {
//    private final PasswordEncoder passwordEncoder;
//
//    public WebSecurityConfig(PasswordEncoder passwordEncoder) {
//        this.passwordEncoder = passwordEncoder;
//    }
//
//
//    public SecurityFilterChain securityFilterChain(HttpSecurity http){
//
//    }
//
//}
//
//
////add in main a new bean for password encoder
//
//
////for header to show user
//// <th:block th:if="${#request.getRemoteUser()!=null}"  th:text="${#request.getRemoteUser()}"
//
//
////to hide button
////<th:block sec:authorize="hasRole('ROLE_ADMIN')"
//
//
////user
////Sttring username= req.getRemoteUser();