//package mk.finki.ukim.mk.lab1_a;
//
//import org.springframework.boot.SpringApplication;
//import org.springframework.boot.autoconfigure.SpringBootApplication;
//import org.springframework.boot.web.servlet.ServletComponentScan;
//
//@SpringBootTest
//class Lab1AApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}
