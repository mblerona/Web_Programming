package mk.finki.ukim.mk.lab1_a.service.impl;

import mk.finki.ukim.mk.lab1_a.model.Role;
import mk.finki.ukim.mk.lab1_a.model.User;
import mk.finki.ukim.mk.lab1_a.model.exceptions.InvalidArgumentException;
import mk.finki.ukim.mk.lab1_a.model.exceptions.PasswordsDontMatchException;
import mk.finki.ukim.mk.lab1_a.model.exceptions.InvalidUserCredentialsException;
import mk.finki.ukim.mk.lab1_a.model.exceptions.UsernameExistsException;
import mk.finki.ukim.mk.lab1_a.repository.jpa.UserRepository;
import mk.finki.ukim.mk.lab1_a.service.UserService;


//import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;


@Service
public class UserServiceImpl implements UserService {

    //private final InMemoryUserRepository userRepository;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;


    public UserServiceImpl(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public User login(String username, String password) {
        if (username == null || username.isEmpty() || password == null || password.isEmpty()) {
            throw new InvalidArgumentException();
        }
        return userRepository.findByUsernameAndPassword(username, password).orElseThrow(InvalidUserCredentialsException::new);

    }

    @Override
    public User register(String username, String password, String repeatPassword, String name, String lastName, Role role) {
//        if (username == null || username.isEmpty() || password == null || password.isEmpty()) {
//            throw new InvalidArgumentException();
//        }
//        if (!password.equals(repeatPassword)) {
//            throw new PasswordsDontMatchException();
//        }
//
//        if (this.userRepository.findByUsername(username).isPresent() || !this.userRepository.findByUsername(username).isEmpty())
//            throw new UsernameExistsException(username);
//        User user = new User(username, password, name, lastName,role);
//        return userRepository.save(user);

        if (username == null || password == null || username.isEmpty() || password.isEmpty()) {
            throw new InvalidArgumentException();
        }

        if (!password.equals(repeatPassword)) {
            throw new PasswordsDontMatchException();
        }

        if (this.userRepository.findByUsername(username).isPresent()) {
            throw new UsernameExistsException(username);
        }

        User user = new User(username, passwordEncoder.encode(password), name, lastName, role);

        return userRepository.save(user);

    }

    public Optional<User> findByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    @Override
    public UserDetails loadUserByUsername(String s) throws UsernameNotFoundException {
        return userRepository.findByUsername(s).orElseThrow(
                ()-> new UsernameNotFoundException(s)
        );
    }
}
