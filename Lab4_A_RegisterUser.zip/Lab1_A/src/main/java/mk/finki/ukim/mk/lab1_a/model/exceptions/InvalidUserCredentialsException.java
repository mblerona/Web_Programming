package mk.finki.ukim.mk.lab1_a.model.exceptions;

public class InvalidUserCredentialsException extends RuntimeException {

public InvalidUserCredentialsException(){
    super("Invalid User credentials exception");
}
}
