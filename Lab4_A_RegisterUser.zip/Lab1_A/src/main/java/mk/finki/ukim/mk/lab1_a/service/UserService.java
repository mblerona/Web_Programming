package mk.finki.ukim.mk.lab1_a.service;

import mk.finki.ukim.mk.lab1_a.model.Role;
import mk.finki.ukim.mk.lab1_a.model.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.util.Optional;
//extends UserDetailService
public interface UserService extends UserDetailsService {
    User login(String username, String password);
    //User register(String username, String password, String repeatPassword, String name, String lastName);
    //add Role here
    User register(String username, String password, String repeatPassword, String name, String lastName, Role role);
    Optional<User> findByUsername(String username); // Corrected return type

    UserDetails loadUserByUsername(String var1) throws UsernameNotFoundException;

}
