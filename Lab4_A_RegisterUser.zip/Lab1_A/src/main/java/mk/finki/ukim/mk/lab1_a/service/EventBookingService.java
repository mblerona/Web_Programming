package mk.finki.ukim.mk.lab1_a.service;

import mk.finki.ukim.mk.lab1_a.model.EventBooking;
import mk.finki.ukim.mk.lab1_a.model.User;

public interface EventBookingService {
    EventBooking placeBooking(String eventName, int numberOfTickets, User user);
}
