package mk.finki.ukim.mk.lab1_a.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@Entity
@NoArgsConstructor
public class EventBooking {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String eventName;
    private String attendeeName;
    private Long numberOfTickets;

    @ToString.Exclude
    @ManyToOne
    private User user;

    public EventBooking(String eventName, String attendeeName, Long numberOfTickets) {
        this.eventName = eventName;
        this.attendeeName = attendeeName;
        this.numberOfTickets = numberOfTickets;
    }

    public void setNumberOfTickets(Long numberOfTickets) {
        this.numberOfTickets = numberOfTickets;
    }
}
