package mk.finki.ukim.mk.lab1_a.repository.jpa;


import mk.finki.ukim.mk.lab1_a.model.EventBooking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BookingRepository  extends JpaRepository<EventBooking, Long> {

    @Query("SELECT b FROM EventBooking b WHERE b.user.username = :username")
    List<EventBooking> findByUsername(@Param("username") String username);

    

}
