package mk.finki.ukim.mk.lab1_a.web.controller;

import jakarta.servlet.http.HttpSession;
import mk.finki.ukim.mk.lab1_a.model.EventBooking;
import mk.finki.ukim.mk.lab1_a.model.User;
import mk.finki.ukim.mk.lab1_a.service.EventBookingService;
import mk.finki.ukim.mk.lab1_a.service.EventService;
import mk.finki.ukim.mk.lab1_a.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestMapping;

import java.security.Principal;

@Controller
@RequestMapping("/eventBooking")
public class EventBookingController {

    private final EventBookingService eventBookingService;
    private final EventService eventService;
    private final UserService userService;

    public EventBookingController(EventBookingService eventBookingService, EventService eventService, UserService userService) {
        this.eventBookingService = eventBookingService;
        this.eventService = eventService;
        this.userService = userService;
    }




    @PostMapping("/book")
    public String bookEvent(@RequestParam String eventName,
                            @RequestParam int numTickets,
                            Model model,
                            HttpSession session) {
        System.out.println("Received POST /eventBooking/book");
        System.out.println("Event name: " + eventName);
        System.out.println("Number of tickets: " + numTickets);
//String username=req.getRemoteUSer();
        String username = (String) session.getAttribute("loggedUser");
        if (username == null) {
            System.out.println("No logged user found in session. Redirecting to login.");
            return "redirect:/login";
        }

        try {
            User user = userService.findByUsername(username)
                    .orElseThrow(() -> new IllegalArgumentException("User not found"));
            EventBooking booking = eventBookingService.placeBooking(eventName, numTickets, user);
            model.addAttribute("booking", booking);
            System.out.println("Booking successful. Redirecting to confirmation page.");
            return "bookingConfirmation";
        } catch (Exception e) {
            System.out.println("Error during booking: " + e.getMessage());
            model.addAttribute("error", e.getMessage());
            return "redirect:/events";
        }
    }




}
