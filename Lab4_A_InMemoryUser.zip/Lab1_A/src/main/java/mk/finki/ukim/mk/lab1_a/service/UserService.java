package mk.finki.ukim.mk.lab1_a.service;

import mk.finki.ukim.mk.lab1_a.model.User;

import java.util.Optional;
//extends UserDetailService
public interface UserService {
    User login(String username, String password);
    User register(String username, String password, String repeatPassword, String name, String lastName);
//add Role here
    Optional<User> findByUsername(String username); // Corrected return type

}
