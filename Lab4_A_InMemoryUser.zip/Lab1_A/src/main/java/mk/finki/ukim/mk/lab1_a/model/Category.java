package mk.finki.ukim.mk.lab1_a.model;

public enum Category {
    MUSIC, ART, THEME_PARTY, SCIENCE
}
