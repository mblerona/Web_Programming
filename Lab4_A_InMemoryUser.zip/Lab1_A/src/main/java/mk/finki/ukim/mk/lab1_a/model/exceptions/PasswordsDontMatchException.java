package mk.finki.ukim.mk.lab1_a.model.exceptions;

public class PasswordsDontMatchException extends RuntimeException{
  public PasswordsDontMatchException(){
      super("Passwords Do not Match");
  }
}
